// logic.ts




export function splitString(input: string): { revisedString: string } {
    const revisedString = input.split('_').join(' ');
    return { revisedString };
}

export function concatenateStrings(param1: string, param2: string): { revisedString: string } {
    const revisedString = param1 + param2;
    return { revisedString };
}

export function isLeapYear(year: number): { year: number; Result: string } {

    if (year % 4 === 0 && (!(year % 100 === 0) || year % 400 === 0)) {
        return { year, Result: 'Leap Year' };
    } else {
        return { year, Result: 'Non Leap Year' };
    }
}


export function secretHandshake(number: number): string[] {
    const binaryString = (number >>> 0).toString(2); // Convert number to binary string
    
    const binaryDigits = binaryString.padStart(5, "0").split("").reverse(); // Pad with zeros and reverse

    const actions: string[] = [];

    // Loop through binary digits and determine actions
    binaryDigits.forEach((digit, index) => {
        if (digit === "1") {
            switch (index) {
                case 0:
                    actions.push("wink");
                    break;
                case 1:
                    actions.push("double blink");
                    break;
                case 2:
                    actions.push("close your eyes");
                    break;
                case 3:
                    actions.push("jump");
                    break;
                case 4:
                    actions.reverse();
                    break;
                default:
                    break;
            }
        }
    });

    return actions;
}
