"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const logic_1 = require("./logic");
const app = (0, express_1.default)();
const PORT = 8000;
app.get('/split/:input', (req, res) => {
    const input = req.params.input;
    const result = (0, logic_1.splitString)(input);
    res.json(result);
});
app.get('/concatenate', (req, res) => {
    const param1 = req.query.param1;
    const param2 = req.query.param2;
    const result = (0, logic_1.concatenateStrings)(param1, param2);
    res.json(result);
});
app.get('/leap-year/:year', (req, res) => {
    const year = parseInt(req.params.year);
    const result = (0, logic_1.isLeapYear)(year);
    res.json(result);
});
app.get('/secret-handshake/:number', (req, res) => {
    const number = parseInt(req.params.number);
    if (isNaN(number) || number < 1 || number > 31) {
        return res.status(400).json({ error: "Invalid number. Please provide a number between 1 and 31." });
    }
    const actions = (0, logic_1.secretHandshake)(number);
    res.json({ number, actions });
});
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
