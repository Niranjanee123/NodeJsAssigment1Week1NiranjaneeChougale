import express, { Request, Response } from 'express';
import { splitString, concatenateStrings, isLeapYear,secretHandshake } from './logic';

const app = express();
const PORT = 8000;

app.get('/split/:input', (req: Request, res: Response) => {
    const input = req.params.input;
    const result = splitString(input);
    res.json(result);
});

app.get('/concatenate', (req: Request, res: Response) => {
    const param1 = req.query.param1 as string;
    const param2 = req.query.param2 as string;
    const result = concatenateStrings(param1, param2);
    res.json(result);
});

app.get('/leap-year/:year', (req: Request, res: Response) => {
    const year = parseInt(req.params.year);
    const result = isLeapYear(year);
    res.json(result);
});


app.get('/secret-handshake/:number', (req: Request, res: Response) => {
    const number = parseInt(req.params.number);
    if (isNaN(number) || number < 1 || number > 31) {
        return res.status(400).json({ error: "Invalid number. Please provide a number between 1 and 31." });
    }

    const actions = secretHandshake(number);
    res.json({ number, actions });
});


app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
