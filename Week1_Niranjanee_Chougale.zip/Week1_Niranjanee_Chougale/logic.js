"use strict";
// logic.ts
Object.defineProperty(exports, "__esModule", { value: true });
exports.secretHandshake = exports.isLeapYear = exports.concatenateStrings = exports.splitString = void 0;
function splitString(input) {
    const revisedString = input.split('_').join(' ');
    return { revisedString };
}
exports.splitString = splitString;
function concatenateStrings(param1, param2) {
    const revisedString = param1 + param2;
    return { revisedString };
}
exports.concatenateStrings = concatenateStrings;
function isLeapYear(year) {
    if (year % 4 === 0 && (!(year % 100 === 0) || year % 400 === 0)) {
        return { year, Result: 'Leap Year' };
    }
    else {
        return { year, Result: 'Non Leap Year' };
    }
}
exports.isLeapYear = isLeapYear;
function secretHandshake(number) {
    const binaryString = (number >>> 0).toString(2); // Convert number to binary string
    const binaryDigits = binaryString.padStart(5, "0").split("").reverse(); // Pad with zeros and reverse
    const actions = [];
    // Loop through binary digits and determine actions
    binaryDigits.forEach((digit, index) => {
        if (digit === "1") {
            switch (index) {
                case 0:
                    actions.push("wink");
                    break;
                case 1:
                    actions.push("double blink");
                    break;
                case 2:
                    actions.push("close your eyes");
                    break;
                case 3:
                    actions.push("jump");
                    break;
                case 4:
                    actions.reverse();
                    break;
                default:
                    break;
            }
        }
    });
    return actions;
}
exports.secretHandshake = secretHandshake;
